package MainFiles;

public class Node {
    int data;  // gets the data for the node
    Node nextPointer;  // gives the next pointer to the node
    static int getCount = 0;

    // generating the method to create a new Node for the same
    public Node(int data) {
        this.data = data;
        this.nextPointer = null;
        Node.getCount++;
    }

    // function to keep a count of the nodes
    public static int getNodeCount(){
        return getCount;
    }
}
