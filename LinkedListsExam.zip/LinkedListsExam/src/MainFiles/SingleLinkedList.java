package MainFiles;

import CustomExceptions.LinkedListExceptions;

import java.util.ArrayList;

public class SingleLinkedList {

    private static Node head = null;   // defining the head of the linked list to be null

    // function to check whether the linked list is empty or not
    public void isEmpty() throws LinkedListExceptions {
        if(Node.getNodeCount() == 0)  // getting the count of the nodes in the linked list
            throw new LinkedListExceptions("The linked list is empty");
    }

    // function to display the linked list
    public void display() throws LinkedListExceptions {
        isEmpty();   // first check whether the linked list is empty or not
        Node temporary = head;
        System.out.println("=================================================================");
        System.out.println("\nThe linked list is: ");
        while(temporary!=null){
            System.out.print(temporary.data + "->");
            temporary = temporary.nextPointer;
        }
        System.out.println("\n=================================================================");
    }

    public void insertAtBeginning(int data){
        Node newNode = new Node(data);  // creating the new Node
        if(head == null){  // when the head of the linked list does not exist
            head = newNode;   // making the current node the head of the linkedlist
            System.out.println("\nNode inserted at the head of the linked list successfully");
        }
        else{
            newNode.nextPointer = head;  // next pointer of the new node points to head
            head = newNode;  // the head now holds the value of the new node
            System.out.println("\nNode inserted at the beginning successfully");
        }
    }

    public void insertAtEnd(int data){
        Node endNode = new Node(data);
        if(head == null){  // when the head of the linked list does not exist
            head = endNode;   // making the current node the head of the linkedlist
            System.out.println("\nNode inserted at the head of the linked list successfully");
        }
        else{
            Node traversal = head;
            while(traversal.nextPointer!=null){
                traversal = traversal.nextPointer;  // traversing the linked list till the end to get the last node
            }
            traversal.nextPointer = endNode;  // make the pointer of the last node point to the new node
            System.out.println("\nNode inserted at the end of the linked list successfully");
        }
    }

    public void deleteNode(int data){
        Node temp = head, previousNode = null;

        // If head node itself holds the data to be deleted
        if (temp != null && temp.data == data) {
            head = temp.nextPointer; // Changed head
            return;
        }

        while(temp!=null && temp.data != data){
            previousNode = temp;   // storing the previous node in the given pointer
            temp = temp.nextPointer;  // traversing the list
        }

        previousNode.nextPointer = temp.nextPointer;
        Node.getCount--;
        System.out.println("\nNode has been deleted successfully");
    }

    public void deleteAtPosition(int position){
        Node traversal = head, previous = null;
        for (int i = 0; i < position ; i++) {
            if (traversal != null){
                previous = traversal;  // storing the previous node with the current node
                traversal = traversal.nextPointer; // traversing the list thus changing the current node
            }
        }
        previous.nextPointer = traversal.nextPointer;
        Node.getCount--;
        System.out.println("\nNode has been deleted successfully");
    }

    public void findMiddle(){
        Node slowPointer = head, fastPointer = head.nextPointer.nextPointer;
        while(fastPointer!=null && fastPointer.nextPointer!=null){
            slowPointer = slowPointer.nextPointer;
            fastPointer = fastPointer.nextPointer;
        }
        System.out.println("\nThe middle element of the linked list: " + slowPointer.data);
    }

    public void getMinimumElement(){
        int minimum = head.data;
        Node current = head.nextPointer;
        while (current!=null){
            if(current.data < minimum)
                minimum = current.data;
            current = current.nextPointer;
        }
        System.out.println("\nThe minimum element of the linked list: " + minimum);
    }

    public void getMaximumElement(){
        int maximum = 0;
        Node traversal = head;
        while(traversal!=null){
            if(traversal.data > maximum)  // checking if the current data is greater than the set counter for the maximum element
                maximum = traversal.data;  // if yes then change the value of the maximum variable to the current value
            traversal = traversal.nextPointer;  // traversing the list
        }
        System.out.println("\nThe maximum element in the linked list is: " + maximum);
    }

    public void searchElement(int element) throws LinkedListExceptions {
        Node traversal = head;
        int position = 0;
        while(traversal!=null){
            if(traversal.data == element){
                System.out.println("\nThe element exists in the linked list at the position: " + position);
                return;
            }
            traversal = traversal.nextPointer;
            position++;
        }
        throw new LinkedListExceptions("Element does not exist in the linked list");
    }

    public boolean isSorted(){
        Node traversal = head;  // setting the current node for traversal purpose
        boolean flag = true;
        while (traversal.nextPointer!=null){
            if(traversal.data < traversal.nextPointer.data)
                return flag;
            else
                flag = false;
            traversal = traversal.nextPointer;
        }
        return flag;
    }

    // this function will only work when the linked list is sorted in the ascending order completely
    public void addSorted(int data) throws LinkedListExceptions {
        if(isSorted()) {
            Node addNode = new Node(data);
            // considering the data to be inserted is smaller than the head node
            if(addNode.data < head.data){
                addNode.nextPointer = head;
                head = addNode;
            }
            else {
                Node currentNode = head, nextNode = head.nextPointer;
                while (currentNode != null && nextNode != null) {
                    if (addNode.data > currentNode.data && addNode.data < nextNode.data) {
                        // add the node in the linked list
                        currentNode.nextPointer = addNode;
                        addNode.nextPointer = nextNode;
                    }
                    currentNode = currentNode.nextPointer;
                    nextNode = nextNode.nextPointer;
                }
            }
        }
        else {
            throw new LinkedListExceptions("List is not sorted");
        }
    }

    public void sortList(){
        Node current = head, index = null;
        int temp;
        if (head == null) {
            return;
        }
        else {
            while (current != null) {
                // Node index will point to node next to current
                index = current.nextPointer;
                while (index != null) {
                    // If current node's data is greater than index's node data, swap the data between them
                    if (current.data > index.data) {
                        temp = current.data;
                        current.data = index.data;
                        index.data = temp;
                    }
                    index = index.nextPointer;
                }
                current = current.nextPointer;
            }
        }
        System.out.println("\nSorting operation carried out successfully");
    }

    public void removeDuplicates(){
        ArrayList<Integer> checker = new ArrayList<>();
        Node traversal = head, previousNode = null;  // setting the head node for the same

        while(traversal!=null){
            if(checker.contains(traversal.data)) {
                previousNode.nextPointer = traversal.nextPointer;
            }
            else{
                checker.add(traversal.data);
                previousNode = traversal;
            }
            traversal = traversal.nextPointer;
        }
        System.out.println("\nRemoved duplicate successfully");
    }
}
