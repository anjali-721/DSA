package Tester;

import MainFiles.Node;
import MainFiles.SingleLinkedList;

import java.util.Scanner;

public class tester1 {
    public static void main(String[] args) {
        System.out.println("\nCode for the implementation of: Singly Linked List");
        try(Scanner scanner = new Scanner(System.in)){
            boolean running = true;
            SingleLinkedList linkedList = new SingleLinkedList();
            while (running){
                try{
                    System.out.print("\n1. Show the contents of linked list\n" +
                            "2. Insert the data in the linked list\n" +
                            "3. Insert the data at the end of the list\n" +
                            "4. Delete a node from the linked list\n" +
                            "5. Check how many elements are there in the linked list.\n" +
                            "6. Removes an element at a given position in the linked list.\n" +
                            "7. Check if the linked list is empty.\n" +
                            "8. Check if the linked list is sorted or not:\n " +
                            "9. Add a new element in sorted order in the sorted list: \n" +
                            "10. Get the minimum and maximum element in the list: \n" +
                            "11. Search for an element in the list: \n" +
                            "12. Sorting the linked list: \n" +
                            "13. Removing the duplicates from the linked list: \n" +
                            "14. Finding the middle element of the linked list: \n" +
                            "Your choice: ");
                    switch (scanner.nextInt()){

                        case 1:{
                            // displaying the contents of the linked list
                            linkedList.display();
                            break;
                        }

                        case 2:{
                            // adding nodes to the linked list. Adding nodes in the beginning
                            System.out.println("\nEnter the element to be added to the linked list: ");
                            linkedList.insertAtBeginning(scanner.nextInt());
                            break;
                        }

                        case 3:{
                            System.out.println("\nEnter the element to be added to the end of the linked list: ");
                            linkedList.insertAtEnd(scanner.nextInt());
                            break;
                        }

                        case 4:{
                            System.out.println("Enter the element to be deleted from the linked list: ");
                            linkedList.deleteNode(scanner.nextInt());
                            break;
                        }

                        case 5:{
                            System.out.println("\n============================================================");
                            System.out.println("\nThe number of nodes in the linked list is: " + Node.getNodeCount());
                            System.out.println("\n=============================================================\n");
                            break;
                        }

                        case 6:{
                            System.out.println("Enter the position to be deleted from the linked list: ");
                            linkedList.deleteAtPosition(scanner.nextInt());
                            break;
                        }

                        case 7:{
                            if(Node.getNodeCount() == 0)
                                System.out.println("\nThe linked list is empty");
                            else
                                System.out.println("\nThe linked list is not empty");
                            break;
                        }

                        case 8:{
                            System.out.println("\nThe linked list sorted function returns: " + linkedList.isSorted());
                            break;

                        }

                        case 9:{
                            System.out.println("\nEnter the element to be added from the linked list: ");
                            linkedList.addSorted(scanner.nextInt());
                            break;
                        }

                        case 10:{
                            System.out.println("\nFinding the maximum and minimum element from the linked list: ");
                            linkedList.getMaximumElement();
                            linkedList.getMinimumElement();
                            break;
                        }

                        case 11:{
                            System.out.println("\nEnter the element to be searched: ");
                            linkedList.searchElement(scanner.nextInt());
                            break;
                        }

                        case 12:{
                            System.out.println("\nExecution of sorting the linked list: ");
                            linkedList.sortList();
                            break;
                        }

                        case 13:{
                            System.out.println("\nExecution of removing duplicates from the list: ");
                            linkedList.removeDuplicates();
                            break;
                        }

                        case 14:{
                            System.out.println("\nExecution of finding the middle element of the linked list: ");
                            linkedList.findMiddle();
                            break;
                        }

                        default:{
                            System.out.println("\nHere the assignment code ends.");
                            running = false;
                            break;
                        }
                    }
                }
                catch (Exception exception){
                    scanner.nextLine();
                    exception.printStackTrace();
                }
            }
        }
    }
}
