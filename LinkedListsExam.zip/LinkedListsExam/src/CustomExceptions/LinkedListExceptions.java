package CustomExceptions;

// generating the custom linked list exceptions class
public class LinkedListExceptions extends Exception{
    public LinkedListExceptions(String message) {
        super(message);
    }
}
