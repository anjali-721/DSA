package ExceptionFile;

// creating a custom exceptions class for throwing out custom stack exceptions to the user
public class CustomStackException extends Exception{
    public CustomStackException(String message) {
        super(message);
    }
}
