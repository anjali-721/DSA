package MainFiles;

import ExceptionFile.CustomStackException;

public class StacksImplementation implements Stacks{

    private int size;  // defining the variable for the stack size
    private int[] stacksArray;  // defining the stacks array
    private int top = -1;
    private int elementCount;  // storing the count of elements in the stack
    int maxElement;  // storing the maximum element of the stack

    public StacksImplementation(int size){
        this.size = size;  // setting the size of the stacks
        stacksArray = new int[size];  // defining the array of a particular size for the user
        this.elementCount = 0;
    }

    // getter method to get the umber of elements of the stack
    public int getElementCount() {
        return elementCount;
    }

    // function to display the elements of the stack
    @Override
    public void display() throws CustomStackException {
        if(isEmpty()){
            throw new CustomStackException("The stack is empty");
        }
        else {
            int traverse = top;
            System.out.println("\n=================================================");
            System.out.println("\nThe elements of the stack are: ");
            while (traverse >= 0) {
                System.out.print(stacksArray[traverse--] + "->");
            }
            System.out.println("\n=================================================");
        }
    }

    @Override
    public void push(int element) throws CustomStackException {
        if(top>this.size)
            throw new CustomStackException("Stack overflow. Element cannot be inserted");  // throwing an exception
        else{
            if(isEmpty()){
                // if the stack is empty then assign the first entered value to the maxElement variable
                maxElement = element;
                stacksArray[++top] = element;
                this.elementCount++;
            }
            else{
                if(element > maxElement)
                    maxElement = element;   // changing the value of the max element to the current element
                stacksArray[++top] = element;   // inserting the element and incrementing the value of top
                System.out.println("Element inserted successfully");
                this.elementCount++;
            }
        }
    }

    @Override
    public void pop() {
        System.out.println("\nThe popped out element from the stack is: " + stacksArray[top--]);
        this.elementCount--;  // changing the count of the elements
    }

    @Override
    public void peek() {
        System.out.println("\nThe peeked out element from the stack is: " + stacksArray[top]);
    }

    @Override
    public void getMaxElement() {
        System.out.println("\nThe max element inside the stack becomes: " + this.maxElement);
    }

    @Override
    public boolean isEmpty() {
        if(top == -1)  // checking if the top is -1 this means no change in size
            return true;  // as we already have top = -1 so no element in stack, is empty is true
        else
            return false;  // this means there are elements present in the stack
    }
}
