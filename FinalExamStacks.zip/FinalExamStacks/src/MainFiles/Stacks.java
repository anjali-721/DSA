package MainFiles;

import ExceptionFile.CustomStackException;

public interface Stacks {

    public void display() throws CustomStackException;
    public void push(int element) throws CustomStackException;
    public void pop();
    public void peek();
    public void getMaxElement();
    public boolean isEmpty();
}
