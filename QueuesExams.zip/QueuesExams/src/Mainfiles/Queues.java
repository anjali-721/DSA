package Mainfiles;

import Exceptionfiles.CustomQueueException;

public interface Queues {

    public boolean isEmpty() throws CustomQueueException;  // function to check whether the queue is empty
    public void isFull(int elementCount) throws CustomQueueException;  // function to check whether the queue is full
    public void enqueue(int element);  // add element in the queue
    public void dequeue();  // function to remove the element from the queue
    public void display() throws CustomQueueException;  // function to the display the elements from the queue
}
