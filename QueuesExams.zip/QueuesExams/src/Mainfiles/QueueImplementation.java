package Mainfiles;

import Exceptionfiles.CustomQueueException;

public class QueueImplementation implements Queues{

    // data members of the class

    private int front;  // pointer used for the deletion of the element from the queue
    private int rear;   // pointer used for the addition of the element in the queue
    private int size;  // variable for the size of the queue
    private int[] queueArray;  // defining the queue array
    private static int elementCount;  // get the count of the count of the elements in the queue

    public QueueImplementation(int size) {
        this.front = -1;
        this.rear = -1;
        this.size = size;
        queueArray = new int[size];   // definition of the array with the size
    }

    public static int getElementCount(){return elementCount;}  // returning the elements in the queue

    @Override
    public boolean isEmpty() throws CustomQueueException {
        if(this.front == -1 && this.rear == -1)
            throw new CustomQueueException("The queue is empty. No elements exist in the queue");
        else
            return false;
    }

    @Override
    public void isFull(int elementCount) throws CustomQueueException {
        if(this.front == 0 && this.rear <= elementCount - 1)
            throw new CustomQueueException("Queue is full. No further elements can be added");
    }

    @Override
    public void enqueue(int element) {
        if(this.front == -1 && this.rear == -1)  // this means the queue is currently empty
        {
            // so the incoming element will be the first one
            // since an array based approach so we need to increment front and rear both here so index becomes 0
            this.front++;
            queueArray[++rear] = element;
            elementCount++;  // incrementing the element count
            System.out.println("\nFirst element inserted in the queue");
        }
        else{
            queueArray[++rear] = element;
            elementCount++;
            System.out.println("\nElement inserted in the queue");
        }
    }

    @Override
    public void dequeue() {
        /*
        condition 1. queue has only one element in that case use rear
        condition 2. queue has multiple element then use front
         */
        if(front == rear){
            int element = queueArray[rear];
            this.front = this.rear = -1;
            System.out.println("\nElement removed from the queue is: " + element);
            elementCount--;
        }
        else{
            int element = queueArray[front++];
            System.out.println("\nElement removed from the queue is: " + element);
            elementCount--;
        }
    }

    @Override
    public void display() throws CustomQueueException {
        isEmpty();
        System.out.println("\n================================================");
        System.out.println("\nThe elements of the queue are as follows: ");
        for (int i = this.front; i <= this.rear; i++) {
            System.out.print(queueArray[i] + "->");
        }
        System.out.println("\n=================================================");
    }
}
