package Exceptionfiles;

// writing the custom exception class for the queue data structure
public class CustomQueueException extends Exception{
    public CustomQueueException(String message) {
        super(message);
    }
}
