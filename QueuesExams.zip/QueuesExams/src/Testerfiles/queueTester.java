package Testerfiles;

import Mainfiles.QueueImplementation;

import java.util.Scanner;

public class queueTester {
    public static void main(String[] args) {
        System.out.println("The code for the queue implementation using arrays: ");
        int size;
        try(Scanner scanner = new Scanner(System.in)){
            System.out.println("Enter the size of the queue: ");
            size = scanner.nextInt();
            QueueImplementation queue = new QueueImplementation(size);
            boolean running = true;
            while (running){
                try{
                    System.out.println("\n1. Add elements in the Queue: \n" +
                            "2. Remove element from the queue: \n" +
                            "3. Display the queue: \n" +
                            "4. Check number of elements in the queue: \n" +
                            "5. Check if the queue is full: \n" +
                            "6. Check if the queue is empty: \n" +
                            "\n Your choice: ");
                    switch(scanner.nextInt()){
                        case 1:{
                            System.out.println("\nEnter the element to be added in the queue: ");
                            queue.enqueue(scanner.nextInt());
                            break;
                        }

                        case 2:{
                            System.out.println("\nImplementing the dequeue function for the queue: ");
                            queue.dequeue();
                            break;
                        }

                        case 3:{
                            System.out.println("\nExecuting the display function: ");
                            queue.display();
                            break;
                        }

                        case 4:{
                            System.out.println("\nThe number of elements in the queue: " + QueueImplementation.getElementCount());
                            break;
                        }

                        case 5:{
                            System.out.println("Checking if the queue is full");
                            queue.isFull(QueueImplementation.getElementCount());
                            break;
                        }

                        case 6:{
                            System.out.println("Checking if the queue is empty");
                            boolean answer = queue.isEmpty();
                            if(answer == false)
                                System.out.println("Queue is not empty");
                            break;
                        }

                        default:{
                            System.out.println("\nThe code ends here");
                            running = false;
                            break;
                        }
                    }
                }
                catch (Exception exception){
                    scanner.nextLine();
                    exception.printStackTrace();
                }
            }
        }
    }
}
