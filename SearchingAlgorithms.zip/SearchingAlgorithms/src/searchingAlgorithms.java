import java.util.Arrays;
import java.util.Scanner;

public class searchingAlgorithms {

    public static void linearSearch(int[] searchArray, int target){
        for (int element: searchArray) {
            if(element == target) {
                System.out.println("Element exists in the array");
                return;
            }
        }
        System.out.println("\nThe element does not exist");
    }

    public static int binarySearch(int[] searchArray, int target){

        // the binary search works on the concept of making partition until the element is found
        /*
            consist of two partition left and right
            left will be from 0 to mid and right from mid to last element index
            keep on making sub arrays until the element is found
         */

        int leftPointer = 0;  // the first index
        int rightPointer = searchArray.length - 1;  // the last index

        // consider the array = [1,2,3,4,5,6,7,8,9]  mid will be arr[4] = 5
        // suppose element to be searched is 2

        while (leftPointer <= rightPointer){
            int mid = (leftPointer + rightPointer)/2;

            // if element is the mid element
            if(searchArray[mid] == target){
                return mid;
            } else if (target < searchArray[mid]) {
                rightPointer = mid;
            }
            else{
                leftPointer = mid;
            }
        }
        return -1;  // in case the element does not exist in the array
    }


    public static void main(String[] args) {
        try(Scanner scanner = new Scanner(System.in)){
            System.out.println("\nThe code for the searching algorithms");
            int searchArray[] = {10,11,7,8,9,23,34,45};
            int searchArray2[] = {1,2,3,4,5,6,7,8,9,10};
            System.out.println("1. Linear Search: \n" +
                    "2. Binary Search: \n" +
                    "Your choice: ");
            switch (scanner.nextInt()){
                case 1:{
                    System.out.println("\nThe array is: " + Arrays.toString(searchArray));
                    System.out.println("\nEnter the element to be searched: ");
                    linearSearch(searchArray, scanner.nextInt());
                    break;
                }

                case 2:{
                    System.out.println("\nThe array is: " + Arrays.toString(searchArray2));
                    System.out.println("\nEnter the element to be searched: ");
                    int position = binarySearch(searchArray2, scanner.nextInt());
                    System.out.println("Element found at position: " + position);
                    break;
                }

                default:{
                    System.out.println("Invalid option selection");
                    break;
                }
            }
        }
    }
}
