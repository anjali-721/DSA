package ExceptionsFiles;

public class CustomExceptions extends Exception{
    public CustomExceptions(String message) {
        super(message);
    }
}
