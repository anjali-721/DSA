package CodeFiles;

public class Node {
    int data;
    Node nextPointer;
    static int nodeCount = 0;

    public Node(int data) {
        this.data = data;
        this.nextPointer = null;
        Node.nodeCount++;
    }

    public static int getNodeCount() {
        return nodeCount;
    }
}
