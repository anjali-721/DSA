package CodeFiles;

import ExceptionsFiles.CustomExceptions;

import java.util.List;

public class LinkedListImplementation implements LinkedList{

    private Node headNode = null;  // declaring the head node of the linked list

    public void isEmpty() throws CustomExceptions {
        if(Node.getNodeCount() == 0)  // getting the count of the nodes in the linked list
            throw new CustomExceptions("The linked list is empty");
    }

    @Override
    public void insertEnd(int element) {
        Node endNode = new Node(element);
        if(headNode == null){
            headNode = endNode;
            System.out.println("\nElement inserted at the head of the linked list");
        }
        else{
            Node current = headNode;
            while(current!=null){
                current = current.nextPointer;
            }
            current.nextPointer = endNode;
            System.out.println("\nNode inserted at the end of the linked list");
        }
    }

    @Override
    public void insertIndex(int element, int index) {
        Node newNode = new Node(element);  // creating the node
        Node current = headNode;
        for (int i = 0; i < index; i++) {
            if(current!=null)
                current = current.nextPointer;
        }
        current.nextPointer = newNode;
        System.out.println("\nNode inserted after: " + index + " successfully");
    }

    @Override
    public void removeAll(int element) {
        if (headNode == null) {  // case when the linked list is empty
            return;
        }
        // Handle the case where the element to be removed is at the beginning of the list
        while (headNode != null && headNode.data == element) {
            headNode = headNode.nextPointer;
        }
        // Traverse the list and remove occurrences of the specified element
        Node current = headNode;
        while (current != null && current.nextPointer != null) {
            if (current.nextPointer.data == element) {
                current.nextPointer = current.nextPointer.nextPointer;
            } else {
                current = current.nextPointer;
            }
        }
    }

    @Override
    public void display() throws CustomExceptions {
        isEmpty();
        Node traversal = headNode;
        System.out.println("\n==================================================");
        System.out.println("The elements in the linked list are: ");
        while(traversal!=null){
            System.out.print(traversal.data + "->");
            traversal = traversal.nextPointer;
        }
        System.out.println("\n===================================================");
    }

    @Override
    public void reverse() {
        Node previousNode = null;  // pointer to the previous node
        Node currentNode = headNode, nextNode = null; // pointers to the current and the next node

        while (currentNode != null) {
            nextNode = currentNode.nextPointer;
            currentNode.nextPointer = previousNode;
            previousNode = currentNode;
            currentNode = nextNode;
        }

        headNode = previousNode;
        System.out.println("\nLinked list has been reversed successfully");
    }

    @Override
    public void sort() {
        Node currentNode = headNode, nextNode = null;
        int temp = 0;
        while(currentNode!=null){
            nextNode = currentNode.nextPointer;
            while (nextNode!=null){
                if(currentNode.data > nextNode.data){
                    temp = currentNode.data;
                    currentNode.data = nextNode.data;
                    nextNode.data = temp;
                }
                nextNode = nextNode.nextPointer;
            }
            currentNode = currentNode.nextPointer;
        }
        System.out.println("\nThe linked list has been sorted successfully");
    }

    @Override
    public void addSorted(int element) throws CustomExceptions {
        if(isSorted()){
            Node addNode = new Node(element);
            // considering the data to be inserted is smaller than the head node
            if(addNode.data < headNode.data){
                addNode.nextPointer = headNode;
                headNode = addNode;
                System.out.println("\nNode has been inserted successfully");
            }
            else {
                Node currentNode = headNode, nextNode = headNode.nextPointer;
                while (currentNode != null && nextNode != null) {
                    if (addNode.data > currentNode.data && addNode.data < nextNode.data) {
                        // add the node in the linked list
                        currentNode.nextPointer = addNode;
                        addNode.nextPointer = nextNode;
                    }
                    currentNode = currentNode.nextPointer;
                    nextNode = nextNode.nextPointer;
                }
                System.out.println("\nNode has been inserted successfully");
            }
        }
        else{
            throw new CustomExceptions("Linked list is not sorted");
        }
    }

    @Override
    public void addAll(List<Integer> numbers) throws CustomExceptions {
        for (int elements: numbers) {
            addSorted(elements);
        }
    }

    @Override
    public void remove(int index) throws CustomExceptions {
        if (headNode == null || index < 0) {
            throw new CustomExceptions("Invalid index");
        }
        // If the index is 0, remove the head
        if (index == 0) {
            headNode = headNode.nextPointer;
            return;
        }

        // Traverse to the node before the target index
        Node current = headNode;
        for (int i = 0; current != null && i < index - 1; i++) {
            current = current.nextPointer;
        }

        // If the index is greater than the number of nodes, do nothing
        if (current == null || current.nextPointer == null) {
            throw new CustomExceptions("Index out of bounds");
        }

        // Remove the node at the specified index
        current.nextPointer = current.nextPointer.nextPointer;

    }

    public String toString(){
        StringBuilder result = new StringBuilder();
        Node current = headNode;

        while (current != null) {
            result.append(current.data).append(" ");
            current = current.nextPointer;
        }

        return result.toString().trim();
    }

    @Override
    public int find(int element) {
        Node currentNode = headNode;
        int position = 0;
        while(currentNode != null){
            if(currentNode.data == element){
                return position;
            }
            currentNode = currentNode.nextPointer;
        }
        return -1;  // indicating that the element does not exist in the linked list
    }

    @Override
    public boolean isSorted() {
        Node current = headNode;
        while (current != null && current.nextPointer != null) {
            if (current.data > current.nextPointer.data) {
                return false;
            }
            current = current.nextPointer;
        }
        return true;
    }
}
