package CodeFiles;

import ExceptionsFiles.CustomExceptions;

import java.util.List;

public interface LinkedList {

    public void insertEnd(int element); // add element at the end
    public void insertIndex(int element, int index); // add the element at the given index
    public void removeAll(int element);  // remove all the occurrences of the element from the linked list
    public void display() throws CustomExceptions;  // display the linked list
    public void reverse();  // reverse the linked list

    // paper 3 questions

    public void sort();
    public void addSorted(int element) throws CustomExceptions;  // add element such that the list remains sorted
    public void addAll(List<Integer> numbers) throws CustomExceptions;  // add all the integers to the sorted list
    public void remove(int index) throws CustomExceptions;  // remove the element at the given index
    public String toString();  // returns comma separated elements from the start to the end

    // paper 4 questions

    public int find(int element);
    public boolean isSorted();
}
