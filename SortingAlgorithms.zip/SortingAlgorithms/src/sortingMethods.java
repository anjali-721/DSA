import java.util.Arrays;
import java.util.Scanner;

public class sortingMethods {

    public static void bubbleSort(int[] sortArray){
        int swapping = 0;
        for(int i=0; i < sortArray.length; i++){
            for(int j=1; j < (sortArray.length-i); j++){
                if(sortArray[j-1] > sortArray[j]){
                    //swap elements
                    swapping = sortArray[j-1];
                    sortArray[j-1] = sortArray[j];
                    sortArray[j] = swapping;
                }
            }
        }
    }

    public static void insertionSort(int[] sortArray){
        for (int j = 1; j < sortArray.length; j++) {
            int key = sortArray[j];
            int i = j-1;
            while ( (i > -1) && ( sortArray[i] > key ) ) {
                sortArray[i+1] = sortArray[i];
                i--;
            }
            sortArray[i+1] = key;
        }
    }

    public static void selectionSort(int[] arr){
        for (int i = 0; i < arr.length - 1; i++)
        {
            int index = i;
            for (int j = i + 1; j < arr.length; j++){
                if (arr[j] < arr[index]){
                    index = j;//searching for lowest index
                }
            }
            int smallerNumber = arr[index];
            arr[index] = arr[i];
            arr[i] = smallerNumber;
        }
    }

    public static int quickPartition(int array[], int low, int high) {

        // choose the rightmost element as pivot
        int pivot = array[high];

        // pointer for greater element
        int i = (low - 1);

        // traverse through all elements
        // compare each element with pivot
        for (int j = low; j < high; j++) {
            if (array[j] <= pivot) {

                // if element smaller than pivot is found
                // swap it with the greater element pointed by i
                i++;

                // swapping element at i with element at j
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }

        }
        // swapt the pivot element with the greater element specified by i
        int temp = array[i + 1];
        array[i + 1] = array[high];
        array[high] = temp;

        // return the position from where partition is done
        return (i + 1);
    }

    public static void quickSort(int[] array, int low, int high){
        if (low < high) {

            // find pivot element such that
            // elements smaller than pivot are on the left
            // elements greater than pivot are on the right
            int pi = quickPartition(array, low, high);

            // recursive call on the left of pivot
            quickSort(array, low, pi - 1);

            // recursive call on the right of pivot
            quickSort(array, pi + 1, high);
        }
    }

    public static void merge(int[] array, int p, int q, int r){
        int n1 = q - p + 1;
        int n2 = r - q;

        int L[] = new int[n1];
        int M[] = new int[n2];

        // fill the left and right array
        for (int i = 0; i < n1; i++)
            L[i] = array[p + i];
        for (int j = 0; j < n2; j++)
            M[j] = array[q + 1 + j];

        // Maintain current index of sub-arrays and main array
        int i, j, k;
        i = 0;
        j = 0;
        k = p;

        // Until we reach either end of either L or M, pick larger among
        // elements L and M and place them in the correct position at A[p..r]
        // for sorting in descending
        // use if(L[i] >= <[j])
        while (i < n1 && j < n2) {
            if (L[i] <= M[j]) {
                array[k] = L[i];
                i++;
            } else {
                array[k] = M[j];
                j++;
            }
            k++;
        }

        // When we run out of elements in either L or M,
        // pick up the remaining elements and put in A[p..r]
        while (i < n1) {
            array[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {
            array[k] = M[j];
            j++;
            k++;
        }
    }

    public static void mergeSort(int[] array, int left, int right){
        if (left < right) {

            // m is the point where the array is divided into two sub arrays
            int mid = (left + right) / 2;

            // recursive call to each sub arrays
            mergeSort(array, left, mid);
            mergeSort(array, mid + 1, right);

            // Merge the sorted sub arrays
            merge(array, left, mid, right);
        }
    }

    public static void main(String[] args) {
        try(Scanner scanner = new Scanner(System.in)){
            int sortArray[] = {7,10,6,11,3,2,1,5,13,20};
            System.out.println("\nSorting algorithms code: ");
            System.out.println("\n1. Bubble sort: \n" +
                    "2. Insertion Sort: \n" +
                    "3. Selection Sort: \n" +
                    "4. Quick Sort: \n" +
                    "5. Merge Sort: \n" +
                    "6. Heap Sort: \n" +
                    "Your choice: ");
            switch (scanner.nextInt()){
                case 1:{
                    System.out.println("\n Code for bubble sort: ");
                    bubbleSort(sortArray);
                    System.out.println("\nThe sorted array is: " + Arrays.toString(sortArray));
                    break;
                }

                case 2:{
                    System.out.println("\n Code for insertion sort: ");
                    insertionSort(sortArray);
                    System.out.println("\nThe sorted array is: " + Arrays.toString(sortArray));
                    break;
                }

                case 3:{
                    System.out.println("\n Code for selection sort: ");
                    selectionSort(sortArray);
                    System.out.println("\nThe sorted array is: " + Arrays.toString(sortArray));
                    break;
                }

                case 4:{
                    System.out.println("\n Code for quick sort: ");
                    quickSort(sortArray, 0, sortArray.length-1);
                    System.out.println("\nThe sorted array is: " + Arrays.toString(sortArray));
                    break;
                }

                case 5:{
                    System.out.println("\n Code for merge sort: ");
                    mergeSort(sortArray,0, sortArray.length-1);
                    System.out.println("\nThe sorted array is: " + Arrays.toString(sortArray));
                    break;
                }

                default:{
                    System.out.println("Code ends here");
                    break;
                }
            }
        }
    }
}
